Ogg Theora
==========

.. automodule:: mutagen.oggtheora

.. autoexception:: mutagen.oggtheora.error
    :show-inheritance:

.. autoexception:: mutagen.oggtheora.OggTheoraHeaderError
    :show-inheritance:

.. autoclass:: mutagen.oggtheora.OggTheora(filename)
    :show-inheritance:
    :members:

.. autoclass:: mutagen.oggtheora.OggTheoraInfo
    :members:
