MP3
===

.. automodule:: mutagen.mp3

.. autoclass:: mutagen.mp3.MP3(filename, ID3=None)
    :show-inheritance:
    :members:

.. autoclass:: mutagen.mp3.MPEGInfo()
    :members:

.. autoclass:: mutagen.mp3.BitrateMode()
    :members:

.. autoclass:: mutagen.mp3.EasyMP3(filename, ID3=None)
    :show-inheritance:
    :members:
    :exclude-members: ID3
