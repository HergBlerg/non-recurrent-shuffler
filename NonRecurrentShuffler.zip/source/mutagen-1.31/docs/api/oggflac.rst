Ogg FLAC
========

.. automodule:: mutagen.oggflac

.. autoexception:: mutagen.oggflac.error
    :show-inheritance:

.. autoexception:: mutagen.oggflac.OggFLACHeaderError
    :show-inheritance:

.. autoclass:: mutagen.oggflac.OggFLAC(filename)
    :show-inheritance:

.. autoclass:: mutagen.oggflac.OggFLACStreamInfo()
    :show-inheritance:
    :members:
