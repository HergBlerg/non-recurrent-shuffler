Ogg Opus
========

.. automodule:: mutagen.oggopus

.. autoexception:: mutagen.oggopus.error
    :show-inheritance:

.. autoexception:: mutagen.oggopus.OggOpusHeaderError
    :show-inheritance:

.. autoclass:: mutagen.oggopus.OggOpus(filename)
    :show-inheritance:
    :members:

.. autoclass:: mutagen.oggopus.OggOpusInfo
    :members:
