OGG
===

.. automodule:: mutagen.ogg

.. autoexception:: mutagen.ogg.error

.. autoclass:: mutagen.ogg.OggFileType(filename)
    :show-inheritance:

.. autoclass:: mutagen.ogg.OggPage
    :members:
