Ogg Vorbis
----------

.. automodule:: mutagen.oggvorbis

.. autoexception:: mutagen.oggvorbis.error
    :show-inheritance:

.. autoexception:: mutagen.oggvorbis.OggVorbisHeaderError
    :show-inheritance:

.. autoclass:: mutagen.oggvorbis.OggVorbis(filename)
    :show-inheritance:
    :members:

.. autoclass:: mutagen.oggvorbis.OggVorbisInfo
    :members:
