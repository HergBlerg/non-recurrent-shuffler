Ogg Speex
=========

.. automodule:: mutagen.oggspeex

.. autoexception:: mutagen.oggspeex.error
    :show-inheritance:

.. autoexception:: mutagen.oggspeex.OggSpeexHeaderError
    :show-inheritance:

.. autoclass:: mutagen.oggspeex.OggSpeex(filename)
    :show-inheritance:
    :members:

.. autoclass:: mutagen.oggspeex.OggSpeexInfo
    :members:
